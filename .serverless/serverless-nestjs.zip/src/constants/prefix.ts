export enum Prefix {
  STATS = 'stats',
}
